from markdown_pdf import MarkdownPdf, Section


if __name__ == "__main__":
    parent_folder = "./zenodo_upload/"

    pdf = MarkdownPdf(toc_level=2, optimize=True)

    with open(f"{parent_folder}README.md", "r") as f:
        markdown_content = f.read()

    pdf.add_section(Section(markdown_content, toc=False))
    pdf.save(f"{parent_folder}README.pdf")
