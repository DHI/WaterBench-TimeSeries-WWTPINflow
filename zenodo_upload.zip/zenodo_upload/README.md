# Inflow to a Waste Water Treatment Plant

This README file contains practical information and background information on the data. The dataset can be cited as:

<div style="padding-left: 20px; padding-right: 20px;">DHI. (2025). Inflow to a waste water treatment plant: observations and processed data (1.0) [Data set]. Zenodo. https://doi.org/10.5281/zenodo.15301164 </div>

## Data Description

The dataset contains the following variables, all measured at hourly resolution.

| Label | Description | Units | Provider |
| --- | --- | --- | --- |
| flow | Inflow to WWTP | m<sup>3</sup>/h | (confidential) |
| acc_precip | Accumulated precipitation | mm | DMI |
| mean_pressure | Mean pressure | hPa | DMI |
| mean_radiation | Mean radiation (spectral range: 305-2800nm) | W/m<sup>2 | DMI |
| mean_relative_hum | Mean relative humidity | % | DMI |
| mean_temp | Mean air temperature | &deg;C | DMI |
| temp_grass | Temperature at grass height | &deg;C | DMI |
| temp_soil_10 | Temperature at 10 cm underground | &deg;C | DMI |
| temp_soil_30 | Temperature at 30 cm underground |&deg;C| DMI |

## Intended Use

This repository is aimed at supporting educational, research, and exploratory activities, such as:

- __Experimenting__ with time series models for forecasting
- __Benchmarking__ machine learning (ML) models

Importantly, the resources in the repository are limited to non-commercial purposes.

## Usage Rights

This dataset is subject to the Creative Commons license CC BY. You can read more about the license terms [here](https://creativecommons.org/licenses/by/4.0/legalcode.en).


## Repository Folder Structure

The repository can be found [here](https://github.com/DHI/WaterBench-TimeSeries-WWTPINflow) and is organized as follows:

- `observations` contains all measurements, split in two files for the flow and metereological data.
- `processed` contains the matched data with minimal preprocessing.
- `code` contains _jupyter_ notebooks and scripts to present and explore the data.